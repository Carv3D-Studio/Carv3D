# Source files for TNaming package
set(OCCT_TNaming_FILES_LOCATION "${CMAKE_CURRENT_LIST_DIR}")

set(OCCT_TNaming_FILES
  TNaming.cxx
  TNaming.hxx
  TNaming_Builder.hxx
  TNaming_CopyShape.cxx
  TNaming_CopyShape.hxx

  TNaming_DeltaOnModification.cxx
  TNaming_DeltaOnModification.hxx
  TNaming_DeltaOnRemoval.cxx
  TNaming_DeltaOnRemoval.hxx
  TNaming_Evolution.hxx
  TNaming_Identifier.cxx
  TNaming_Identifier.hxx
  TNaming_Iterator.hxx
  TNaming_Iterator.lxx
  TNaming_IteratorOnShapesSet.hxx
  TNaming_IteratorOnShapesSet.lxx

  TNaming_Localizer.cxx
  TNaming_Localizer.hxx

  TNaming_Name.cxx
  TNaming_Name.hxx
  TNaming_NamedShape.cxx
  TNaming_NamedShape.hxx
  TNaming_NamedShape.lxx
  TNaming_NameType.hxx
  TNaming_Naming.cxx
  TNaming_Naming.hxx
  TNaming_NamingTool.cxx
  TNaming_NamingTool.hxx

  TNaming_NewShapeIterator.hxx
  TNaming_NewShapeIterator.lxx
  TNaming_OldShapeIterator.hxx
  TNaming_OldShapeIterator.lxx
  TNaming_PtrAttribute.hxx
  TNaming_PtrNode.hxx
  TNaming_PtrRefShape.hxx
  TNaming_RefShape.hxx
  TNaming_RefShape.lxx
  TNaming_SameShapeIterator.hxx
  TNaming_SameShapeIterator.lxx
  TNaming_Scope.cxx
  TNaming_Scope.hxx
  TNaming_Selector.cxx
  TNaming_Selector.hxx
  TNaming_ShapesSet.cxx
  TNaming_ShapesSet.hxx
  TNaming_ShapesSet.lxx
  TNaming_Tool.cxx
  TNaming_Tool.hxx
  TNaming_TranslateTool.cxx
  TNaming_TranslateTool.hxx
  TNaming_Translator.cxx
  TNaming_Translator.hxx
  TNaming_UsedShapes.cxx
  TNaming_UsedShapes.hxx
  TNaming_UsedShapes.lxx
)
