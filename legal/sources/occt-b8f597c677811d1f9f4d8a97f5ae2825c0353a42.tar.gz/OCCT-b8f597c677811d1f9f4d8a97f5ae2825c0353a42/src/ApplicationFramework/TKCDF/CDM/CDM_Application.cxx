// Created on: 1997-10-22
// Created by: Jean-Louis Frenkel
// Copyright (c) 1997-1999 Matra Datavision
// Copyright (c) 1999-2014 OPEN CASCADE SAS
//
// This file is part of Open CASCADE Technology software library.
//
// This library is free software; you can redistribute it and/or modify it under
// the terms of the GNU Lesser General Public License version 2.1 as published
// by the Free Software Foundation, with special exception defined in the file
// OCCT_LGPL_EXCEPTION.txt. Consult the file LICENSE_LGPL_21.txt included in OCCT
// distribution for complete text of the license and disclaimer of any warranty.
//
// Alternatively, this file may be used under the terms of Open CASCADE
// commercial license or contractual agreement.

#include <CDM_Application.hxx>
#include <CDM_Document.hxx>
#include <CDM_MetaData.hxx>
#include <Resource_Manager.hxx>
#include <Standard_Dump.hxx>
#include <Standard_Type.hxx>
#include <TCollection_ExtendedString.hxx>
#include <Message.hxx>
#include <Message_Messenger.hxx>

IMPLEMENT_STANDARD_RTTIEXT(CDM_Application, Standard_Transient)

//=================================================================================================

CDM_Application::CDM_Application()
{
  myMessenger = new Message_Messenger;
}

//=================================================================================================

void CDM_Application::SetDocumentVersion(const occ::handle<CDM_Document>& aDocument,
                                         const occ::handle<CDM_MetaData>& aMetaData) const
{
  aDocument->SetModifications(aMetaData->DocumentVersion(this));
}

//=================================================================================================

void CDM_Application::SetReferenceCounter(const occ::handle<CDM_Document>& aDocument,
                                          const int                        aReferenceCounter)
{
  aDocument->SetReferenceCounter(aReferenceCounter);
}

//=================================================================================================

occ::handle<Message_Messenger> CDM_Application::MessageDriver()
{
  return myMessenger;
}

//=================================================================================================

void CDM_Application::Write(const char16_t* const aString)
{
  MessageDriver()->Send(aString);
}

//=================================================================================================

void CDM_Application::BeginOfUpdate(const occ::handle<CDM_Document>& /*aDocument*/)
{
  TCollection_ExtendedString updating("Updating: ");
  updating += "Document";
  Write(updating.ToExtString());
}

//=================================================================================================

void CDM_Application::EndOfUpdate(const occ::handle<CDM_Document>& /*aDocument*/,
                                  const bool theStatus,
                                  const TCollection_ExtendedString& /*ErrorString*/)
{
  TCollection_ExtendedString message;
  if (theStatus)
  {
    message = "Updated: ";
  }
  else
  {
    message = "Error during updating: ";
  }

  message += "Document";
  Write(message.ToExtString());
}

//=================================================================================================

TCollection_ExtendedString CDM_Application::Name() const
{
  // Default: empty
  return TCollection_ExtendedString();
}

//=================================================================================================

TCollection_AsciiString CDM_Application::Version() const
{
  // Default: empty
  return TCollection_AsciiString();
}

//=================================================================================================

NCollection_DataMap<TCollection_ExtendedString, occ::handle<CDM_MetaData>>& CDM_Application::
  MetaDataLookUpTable()
{
  return myMetaDataLookUpTable;
}

//=================================================================================================

void CDM_Application::DumpJson(Standard_OStream& theOStream, int /*theDepth*/) const
{
  OCCT_DUMP_TRANSIENT_CLASS_BEGIN(theOStream)
}
